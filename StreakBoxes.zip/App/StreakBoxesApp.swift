import SwiftUI

@main
struct StreakBoxesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    private let gym = Color(red: 1.00, green: 0.45, blue: 0.10)
    private let study = Color(red: 0.24, green: 0.52, blue: 1.00)

    var body: some View {
        NavigationStack {
            List {
                Section("What the boxes mean") {
                    LegendRow(label: "Did it (Gym)") {
                        RoundedRectangle(cornerRadius: 5, style: .continuous).fill(gym)
                    }
                    LegendRow(label: "Did it (Study)") {
                        RoundedRectangle(cornerRadius: 5, style: .continuous).fill(study)
                    }
                    LegendRow(label: "Missed day") {
                        RoundedRectangle(cornerRadius: 5, style: .continuous).fill(Color.primary.opacity(0.12))
                    }
                    LegendRow(label: "Upcoming day") {
                        RoundedRectangle(cornerRadius: 5, style: .continuous)
                            .strokeBorder(Color.primary.opacity(0.18), lineWidth: 1)
                    }
                    LegendRow(label: "Today (not logged yet)") {
                        RoundedRectangle(cornerRadius: 5, style: .continuous)
                            .strokeBorder(gym, lineWidth: 2)
                    }
                }

                Section("Add the widgets") {
                    Text("1. Go to your Home Screen and press and hold an empty spot until the icons jiggle.")
                    Text("2. Tap Edit (or +) in the top corner, then Add Widget.")
                    Text("3. Search for \"Streaks\". Add Gym Streak and Study Streak in Small, Medium, or Large.")
                }

                Section("Logging") {
                    Text("Tap any past or current box on the widget to color it. Tap it again to clear it.")
                    Text("Medium and Large widgets also have a Log today button.")
                    Text("The streak counts consecutive colored days. If today isn't logged yet, it counts from yesterday, so it won't drop to 0 until a full day is missed.")
                }

                Section("Good to know") {
                    Text("Your history is saved inside the widget on this phone. Deleting this app erases it. Refreshing it in AltStore keeps it.")
                    Text("Requires iOS 17 or later for tappable widgets.")
                }
            }
            .navigationTitle("Streak Boxes")
        }
    }
}

struct LegendRow<Swatch: View>: View {
    let label: String
    @ViewBuilder let swatch: () -> Swatch

    var body: some View {
        HStack(spacing: 12) {
            swatch()
                .frame(width: 22, height: 22)
            Text(label)
        }
    }
}
