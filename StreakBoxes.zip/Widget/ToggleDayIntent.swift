import AppIntents
import WidgetKit

/// Runs inside the widget extension when a box (or the Log button) is tapped.
struct ToggleDayIntent: AppIntent {
    static let title: LocalizedStringResource = "Toggle Day"
    static let isDiscoverable: Bool = false

    @Parameter(title: "Habit")
    var habit: String

    @Parameter(title: "Day")
    var day: String

    init() {}

    init(habit: String, day: String) {
        self.habit = habit
        self.day = day
    }

    func perform() async throws -> some IntentResult {
        StreakStore.toggle(habit: habit, day: day)
        WidgetCenter.shared.reloadAllTimelines()
        return .result()
    }
}
