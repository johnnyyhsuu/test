import WidgetKit
import SwiftUI
import AppIntents

// MARK: - Bundle

@main
struct StreakWidgets: WidgetBundle {
    var body: some Widget {
        GymStreakWidget()
        StudyStreakWidget()
    }
}

struct GymStreakWidget: Widget {
    let kind: String = "GymStreakWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: StreakProvider(habit: .gym)) { entry in
            StreakWidgetView(entry: entry)
        }
        .configurationDisplayName("Gym Streak")
        .description("Tap a box to mark a gym day. Tap again to clear it.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
    }
}

struct StudyStreakWidget: Widget {
    let kind: String = "StudyStreakWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: StreakProvider(habit: .study)) { entry in
            StreakWidgetView(entry: entry)
        }
        .configurationDisplayName("Study Streak")
        .description("Tap a box to mark a study day. Tap again to clear it.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
    }
}

// MARK: - Timeline

struct StreakEntry: TimelineEntry {
    let date: Date
    let habit: Habit
    let done: Set<String>

    var currentStreak: Int { DayMath.currentStreak(done, today: date) }
    var bestStreak: Int { DayMath.bestStreak(done) }
    var monthCount: Int { DayMath.monthCount(done, today: date) }
    var isTodayDone: Bool { done.contains(DayMath.key(date)) }
}

struct StreakProvider: TimelineProvider {
    let habit: Habit

    func placeholder(in context: Context) -> StreakEntry {
        sampleEntry()
    }

    func getSnapshot(in context: Context, completion: @escaping (StreakEntry) -> Void) {
        if context.isPreview {
            completion(sampleEntry())
        } else {
            completion(StreakEntry(date: Date(), habit: habit, done: StreakStore.days(for: habit)))
        }
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<StreakEntry>) -> Void) {
        let now = Date()
        let done = StreakStore.days(for: habit)
        let midnight = DayMath.nextMidnight(after: now)
        let entries = [
            StreakEntry(date: now, habit: habit, done: done),
            StreakEntry(date: midnight, habit: habit, done: done)   // rolls the grid over at 12:00 AM
        ]
        completion(Timeline(entries: entries, policy: .after(midnight)))
    }

    /// Fake data for the widget gallery preview only.
    private func sampleEntry() -> StreakEntry {
        let today = Date()
        var done = Set<String>()
        for i in 0..<40 where i % 5 != 3 {
            done.insert(DayMath.key(DayMath.addDays(-i, to: today)))
        }
        return StreakEntry(date: today, habit: habit, done: done)
    }
}

// MARK: - Views

struct StreakWidgetView: View {
    @Environment(\.widgetFamily) var family
    let entry: StreakEntry

    var body: some View {
        Group {
            switch family {
            case .systemMedium:
                MediumStreakView(entry: entry)
            case .systemLarge:
                LargeStreakView(entry: entry)
            default:
                SmallStreakView(entry: entry)
            }
        }
        .containerBackground(.background, for: .widget)
    }
}

/// One square. Colored = done. Gray fill = missed. Outline only = upcoming.
struct DayBox: View {
    let date: Date
    let state: DayState
    let isToday: Bool
    let color: Color
    let size: CGFloat
    let showNumber: Bool

    var body: some View {
        let shape = RoundedRectangle(cornerRadius: size * 0.24, style: .continuous)
        ZStack {
            switch state {
            case .done:
                shape.fill(color)
            case .missed:
                shape.fill(Color.primary.opacity(0.12))
            case .future:
                shape.strokeBorder(Color.primary.opacity(0.18), lineWidth: 1)
            }
            if isToday && state != .done {
                shape.strokeBorder(color, lineWidth: 2)
            }
            if showNumber {
                Text("\(DayMath.cal.component(.day, from: date))")
                    .font(.system(size: max(9, size * 0.32), weight: .semibold, design: .rounded))
                    .foregroundStyle(state == .done ? Color.white : Color.secondary)
            }
        }
        .frame(width: size, height: size)
    }
}

/// A box that toggles its day when tapped. Upcoming days aren't tappable.
struct DayCell: View {
    let date: Date
    let entry: StreakEntry
    let size: CGFloat
    let showNumber: Bool

    var body: some View {
        let state = DayMath.state(of: date, today: entry.date, done: entry.done)
        let isToday = DayMath.key(date) == DayMath.key(entry.date)
        let box = DayBox(date: date, state: state, isToday: isToday,
                         color: entry.habit.color, size: size, showNumber: showNumber)
        if state == .future {
            box
        } else {
            Button(intent: ToggleDayIntent(habit: entry.habit.rawValue, day: DayMath.key(date))) {
                box
            }
            .buttonStyle(.plain)
        }
    }
}

struct TodayButton: View {
    let entry: StreakEntry

    var body: some View {
        let done = entry.isTodayDone
        Button(intent: ToggleDayIntent(habit: entry.habit.rawValue, day: DayMath.key(entry.date))) {
            HStack(spacing: 4) {
                Image(systemName: done ? "checkmark.circle.fill" : "plus.circle.fill")
                Text(done ? "Done today" : "Log today")
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }
            .font(.system(size: 12, weight: .semibold))
            .foregroundStyle(done ? Color.white : entry.habit.color)
            .padding(.horizontal, 8)
            .padding(.vertical, 6)
            .frame(maxWidth: .infinity)
            .background(done ? entry.habit.color : entry.habit.color.opacity(0.15), in: Capsule())
        }
        .buttonStyle(.plain)
    }
}

struct TitleLabel: View {
    let habit: Habit
    let size: CGFloat

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: habit.symbol)
                .foregroundStyle(habit.color)
            Text(habit.title)
                .lineLimit(1)
        }
        .font(.system(size: size, weight: .semibold))
    }
}

struct StreakBadge: View {
    let streak: Int

    var body: some View {
        HStack(spacing: 2) {
            Text("\(streak)")
                .font(.system(size: 13, weight: .bold, design: .rounded))
            Image(systemName: "flame.fill")
                .font(.system(size: 11))
                .foregroundStyle(streak > 0 ? Color.orange : Color.secondary)
        }
    }
}

// Small: last few weeks as calendar rows (each row = one week).
struct SmallStreakView: View {
    let entry: StreakEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                TitleLabel(habit: entry.habit, size: 13)
                Spacer(minLength: 2)
                StreakBadge(streak: entry.currentStreak)
            }
            GeometryReader { geo in
                let sp: CGFloat = 4
                let box = max(6, floor((geo.size.width - sp * 6) / 7))
                let rows = max(1, Int((geo.size.height + sp) / (box + sp)))
                let weeks = DayMath.weeks(endingWith: entry.date, count: rows)
                VStack(spacing: sp) {
                    ForEach(weeks.indices, id: \.self) { w in
                        HStack(spacing: sp) {
                            ForEach(weeks[w], id: \.self) { day in
                                DayCell(date: day, entry: entry, size: box, showNumber: false)
                            }
                        }
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
            }
        }
    }
}

// Medium: stats + Log button on the left, GitHub-style grid on the right
// (each column = one week, top to bottom = first weekday to last).
struct MediumStreakView: View {
    let entry: StreakEntry

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                TitleLabel(habit: entry.habit, size: 14)
                Spacer(minLength: 0)
                Text("\(entry.currentStreak)")
                    .font(.system(size: 34, weight: .bold, design: .rounded))
                    .minimumScaleFactor(0.5)
                    .lineLimit(1)
                Text("day streak")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                Spacer(minLength: 0)
                TodayButton(entry: entry)
            }
            .frame(width: 100, alignment: .leading)

            GeometryReader { geo in
                let sp: CGFloat = 3
                let box = max(6, floor((geo.size.height - sp * 6) / 7))
                let cols = max(1, Int((geo.size.width + sp) / (box + sp)))
                let weeks = DayMath.weeks(endingWith: entry.date, count: cols)
                HStack(spacing: sp) {
                    ForEach(weeks.indices, id: \.self) { w in
                        VStack(spacing: sp) {
                            ForEach(weeks[w], id: \.self) { day in
                                DayCell(date: day, entry: entry, size: box, showNumber: false)
                            }
                        }
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .trailing)
            }
        }
    }
}

// Large: stats row + a calendar of recent weeks with big, numbered, tappable boxes.
struct LargeStreakView: View {
    let entry: StreakEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                TitleLabel(habit: entry.habit, size: 17)
                Spacer()
                TodayButton(entry: entry)
                    .frame(width: 120)
            }
            HStack(spacing: 0) {
                StatView(value: entry.currentStreak, label: "Current streak")
                StatView(value: entry.bestStreak, label: "Best streak")
                StatView(value: entry.monthCount, label: "This month")
            }
            GeometryReader { geo in
                let sp: CGFloat = 5
                let labelHeight: CGFloat = 12
                let box = max(8, floor((geo.size.width - sp * 6) / 7))
                let rows = max(1, Int((geo.size.height - labelHeight) / (box + sp)))
                let weeks = DayMath.weeks(endingWith: entry.date, count: rows)
                let letters = DayMath.weekdayLetters
                VStack(spacing: sp) {
                    HStack(spacing: sp) {
                        ForEach(letters.indices, id: \.self) { i in
                            Text(letters[i])
                                .font(.system(size: 10, weight: .semibold))
                                .foregroundStyle(.secondary)
                                .frame(width: box, height: labelHeight)
                        }
                    }
                    ForEach(weeks.indices, id: \.self) { w in
                        HStack(spacing: sp) {
                            ForEach(weeks[w], id: \.self) { day in
                                DayCell(date: day, entry: entry, size: box, showNumber: true)
                            }
                        }
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
            }
        }
    }
}

struct StatView: View {
    let value: Int
    let label: String

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("\(value)")
                .font(.system(size: 22, weight: .bold, design: .rounded))
            Text(label)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
