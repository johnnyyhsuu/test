import Foundation
import SwiftUI

// MARK: - Habits

enum Habit: String, CaseIterable {
    case gym
    case study

    var title: String {
        switch self {
        case .gym: return "Gym"
        case .study: return "Study"
        }
    }

    var symbol: String {
        switch self {
        case .gym: return "dumbbell.fill"
        case .study: return "book.fill"
        }
    }

    var color: Color {
        switch self {
        case .gym: return Color(red: 1.00, green: 0.45, blue: 0.10)   // orange
        case .study: return Color(red: 0.24, green: 0.52, blue: 1.00) // blue
        }
    }
}

enum DayState {
    case done    // colored box
    case missed  // uncolored, filled light gray
    case future  // uncolored, outline only
}

// MARK: - Storage
// Data lives inside the widget extension's own container (no App Group needed),
// so it works with AltStore without any special entitlements.

enum StreakStore {
    private static var fileURL: URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("streaks.json")
    }

    static func loadAll() -> [String: Set<String>] {
        guard let data = try? Data(contentsOf: fileURL),
              let raw = try? JSONDecoder().decode([String: [String]].self, from: data) else {
            return [:]
        }
        return raw.mapValues { Set($0) }
    }

    static func saveAll(_ all: [String: Set<String>]) {
        let raw = all.mapValues { $0.sorted() }
        if let data = try? JSONEncoder().encode(raw) {
            try? data.write(to: fileURL, options: .atomic)
        }
    }

    static func days(for habit: Habit) -> Set<String> {
        loadAll()[habit.rawValue] ?? []
    }

    /// Flips a day between done and not done. Future days are ignored.
    static func toggle(habit: String, day: String) {
        guard Habit(rawValue: habit) != nil,
              DayMath.date(fromKey: day) != nil,
              day <= DayMath.key(Date()) else { return }
        var all = loadAll()
        var set = all[habit] ?? []
        if set.contains(day) {
            set.remove(day)
        } else {
            set.insert(day)
        }
        all[habit] = set
        saveAll(all)
    }
}

// MARK: - Date math

enum DayMath {
    static var cal: Calendar {
        var c = Calendar(identifier: .gregorian)
        c.timeZone = TimeZone.current
        c.locale = Locale.current
        c.firstWeekday = Calendar.current.firstWeekday
        return c
    }

    /// "yyyy-MM-dd" in the local time zone.
    static func key(_ date: Date) -> String {
        let c = cal.dateComponents([.year, .month, .day], from: date)
        return String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
    }

    static func date(fromKey key: String) -> Date? {
        let parts = key.split(separator: "-").compactMap { Int($0) }
        guard parts.count == 3 else { return nil }
        var comps = DateComponents()
        comps.year = parts[0]
        comps.month = parts[1]
        comps.day = parts[2]
        guard let d = cal.date(from: comps), DayMath.key(d) == key else { return nil }
        return d
    }

    static func addDays(_ n: Int, to date: Date) -> Date {
        cal.date(byAdding: .day, value: n, to: date) ?? date.addingTimeInterval(Double(n) * 86_400)
    }

    static func nextMidnight(after date: Date) -> Date {
        addDays(1, to: cal.startOfDay(for: date))
    }

    /// `count` weeks of 7 days each; the last week contains `today`.
    static func weeks(endingWith today: Date, count: Int) -> [[Date]] {
        guard count > 0 else { return [] }
        let c = cal
        let thisWeekStart = c.dateInterval(of: .weekOfYear, for: today)?.start ?? c.startOfDay(for: today)
        let firstDay = addDays(-7 * (count - 1), to: thisWeekStart)
        return (0..<count).map { w in
            (0..<7).map { d in addDays(w * 7 + d, to: firstDay) }
        }
    }

    static func state(of date: Date, today: Date, done: Set<String>) -> DayState {
        let k = key(date)
        if k > key(today) { return .future }
        return done.contains(k) ? .done : .missed
    }

    /// Consecutive done days ending today. If today isn't logged yet,
    /// the streak counts back from yesterday so it doesn't reset to 0 in the morning.
    static func currentStreak(_ done: Set<String>, today: Date) -> Int {
        var day = cal.startOfDay(for: today)
        if !done.contains(key(day)) {
            day = addDays(-1, to: day)
        }
        var count = 0
        while done.contains(key(day)) {
            count += 1
            day = addDays(-1, to: day)
        }
        return count
    }

    static func bestStreak(_ done: Set<String>) -> Int {
        let dates = done.compactMap { date(fromKey: $0) }.sorted()
        var best = 0
        var run = 0
        var previous: Date?
        for d in dates {
            if let p = previous, key(addDays(1, to: p)) == key(d) {
                run += 1
            } else {
                run = 1
            }
            best = max(best, run)
            previous = d
        }
        return best
    }

    static func monthCount(_ done: Set<String>, today: Date) -> Int {
        let todayKey = key(today)
        let prefix = String(todayKey.prefix(7))
        return done.filter { $0.hasPrefix(prefix) && $0 <= todayKey }.count
    }

    /// Single-letter weekday labels starting at the locale's first weekday.
    static var weekdayLetters: [String] {
        let c = cal
        let symbols = c.veryShortWeekdaySymbols
        guard symbols.count == 7 else { return ["S", "M", "T", "W", "T", "F", "S"] }
        let start = c.firstWeekday - 1
        return Array(symbols[start...] + symbols[..<start])
    }
}
